#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 51511

// Define the data structure
struct Data {
    int value1;
    float value2;
    char message[128];
};

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    struct Data data_to_send;

    // Create a socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to the server
    if (connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Connection failed");
        exit(EXIT_FAILURE);
    }

    // Prepare the data structure to send
    data_to_send.value1 = 42;
    data_to_send.value2 = 3.14;
    strcpy(data_to_send.message, "Hello from client!");

    // Send the data structure to the server
    send(sockfd, &data_to_send, sizeof(struct Data), 0);

    printf("Data sent to server.\n");

    // Close the socket
    close(sockfd);

    return 0;
}