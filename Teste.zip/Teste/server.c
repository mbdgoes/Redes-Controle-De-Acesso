#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 51511

// Define the data structure
struct Data {
    int value1;
    float value2;
    char message[128];
};

int main() {
    int sockfd, new_sock;
    struct sockaddr_in server_addr, new_addr;
    socklen_t addr_size;
    struct Data received_data;

    // Create a socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket
    if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Binding failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    listen(sockfd, 10);

    printf("Server listening on port %d...\n", PORT);

    while (1) {
        addr_size = sizeof(new_addr);
        new_sock = accept(sockfd, (struct sockaddr*)&new_addr, &addr_size);

        // Receive the data structure from the client
        recv(new_sock, &received_data, sizeof(struct Data), 0);

        printf("Received Data:\n");
        printf("Value 1: %d\n", received_data.value1);
        printf("Value 2: %f\n", received_data.value2);
        printf("Message: %s\n", received_data.message);

        // Close the socket for this client
        close(new_sock);
    }

    // The server will never reach this point

    close(sockfd);

    return 0;
}
